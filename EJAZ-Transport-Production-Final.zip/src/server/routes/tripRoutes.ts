import { Router, type Response } from "express";
import { db, type TripEntity, type TripEventEntity } from "../db";
import { authenticate, optionalAuthenticate, type AuthenticatedRequest } from "../auth/middleware";
import { generateTripNumber } from "../services/tripNumberGenerator";
import { validateTransition, type TripLifecycleStatus, STATUS_LABELS } from "../services/tripLifecycleService";
import { initTripFinancials, getTripFinancials } from "../services/financeService";
import { logAuditEvent } from "../services/auditService";
import { dispatchNotification } from "../services/notificationService";

const router = Router();

// GET /api/trips
router.get("/", optionalAuthenticate, (req: AuthenticatedRequest, res: Response) => {
  const { status, vehicleId, driverId, customerId } = req.query;
  let list = Array.from(db.trips.values());

  if (status && typeof status === "string") {
    list = list.filter((t) => t.status === status);
  }
  if (vehicleId && typeof vehicleId === "string") {
    list = list.filter((t) => t.vehicleId === vehicleId);
  }
  if (driverId && typeof driverId === "string") {
    list = list.filter((t) => t.driverId === driverId);
  }
  if (customerId && typeof customerId === "string") {
    list = list.filter((t) => t.customerId === customerId);
  }

  // Sort by createdAt descending
  list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return res.json({
    total: list.length,
    trips: list,
  });
});

// GET /api/trips/:id
router.get("/:id", optionalAuthenticate, (req: AuthenticatedRequest, res: Response) => {
  const tripId = String(req.params.id);
  const trip = db.trips.get(tripId) || Array.from(db.trips.values()).find((t) => t.tripNumber === tripId);
  if (!trip) {
    return res.status(404).json({ error: "Trip not found" });
  }

  const vehicle = db.vehicles.get(trip.vehicleId);
  const driver = db.drivers.get(trip.driverId);
  const customer = db.customers.get(trip.customerId);
  const events = db.tripEvents.filter((e) => e.tripId === trip.id);
  const financials = getTripFinancials(trip.id);
  const documents = Array.from(db.documents.values()).filter((d) => d.tripId === trip.id);

  return res.json({
    trip,
    vehicle,
    driver,
    customer,
    events,
    financials,
    documents,
    statusMeta: STATUS_LABELS[trip.status as TripLifecycleStatus] || { ar: trip.status, en: trip.status, badgeColor: "#FF7A00" },
  });
});

// POST /api/trips - Create new shipment request
router.post("/", authenticate, (req: AuthenticatedRequest, res: Response) => {
  const {
    originCity,
    destinationCity,
    pickupAddress,
    deliveryAddress,
    cargoDescription,
    cargoType,
    cargoWeightTons,
    maxCapacityTons,
    temperatureRequired,
    tripPrice,
    corridorKey,
    customerId,
    vehicleId,
    driverId,
  } = req.body;

  if (!originCity || !destinationCity || !cargoDescription || !cargoType || !cargoWeightTons) {
    return res.status(400).json({ error: "Missing required trip shipment fields" });
  }

  // Verify cargoType is one of the 4 official types
  const validTypes = ["براد", "سطحة", "جاف", "ستارة"];
  if (!validTypes.includes(cargoType)) {
    return res.status(400).json({
      error: `Invalid vehicle cargo type '${cargoType}'. Official types allowed: ${validTypes.join(", ")}`,
    });
  }

  // Generate Authoritative Trip Number from Backend
  const tripNumber = generateTripNumber(new Date().getFullYear());
  const tripId = `trip-${Date.now()}`;

  const customer = customerId ? db.customers.get(customerId) : undefined;
  const driver = driverId ? db.drivers.get(driverId) : undefined;

  const newTrip: TripEntity = {
    id: tripId,
    tripNumber,
    status: "DRAFT_CREATED",
    customerId: customerId || "cust-1",
    customerName: customer?.name || "شركة سدافكو للأغذية والمشروبات",
    vehicleId: vehicleId || "v1",
    driverId: driverId || "d1",
    driverName: driver?.fullName || "فهد الشمري",
    driverPhone: driver?.phone || "+966551234567",
    originCity,
    destinationCity,
    pickupAddress: pickupAddress || originCity,
    deliveryAddress: deliveryAddress || destinationCity,
    cargoDescription,
    cargoType,
    cargoWeightTons: Number(cargoWeightTons),
    maxCapacityTons: Number(maxCapacityTons || 25),
    temperatureRequired: cargoType === "براد" ? Number(temperatureRequired || -18) : undefined,
    corridorKey: corridorKey || "riyadh-jeddah",
    currentLat: 24.7136,
    currentLng: 46.6753,
    currentSpeed: 0,
    currentHeading: 0,
    departureTime: new Date().toISOString(),
    estimatedArrival: new Date(Date.now() + 8 * 3600 * 1000).toISOString(),
    tripPrice: Number(tripPrice || 4500),
    createdBy: req.user?.userId || "system",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.trips.set(tripId, newTrip);
  initTripFinancials(tripId, tripNumber, newTrip.tripPrice);

  // Record initial creation event
  const createEvent: TripEventEntity = {
    id: `ev-${Date.now()}`,
    tripId,
    eventType: "TRIP_CREATED",
    fromStatus: undefined,
    toStatus: "DRAFT_CREATED",
    actorId: req.user?.userId,
    actorName: req.user?.fullName,
    actorRole: req.user?.role,
    notes: `تم إنشاء الشحنة بنجاح وحجز الرقم المرجعي الموحد ${tripNumber}`,
    timestamp: new Date().toISOString(),
  };
  db.tripEvents.push(createEvent);

  logAuditEvent({
    actorId: req.user?.userId,
    actorName: req.user?.fullName,
    actorRole: req.user?.role,
    action: "TRIP_CREATED",
    entity: "trips",
    entityId: tripId,
    tripId,
    newValues: { tripNumber, originCity, destinationCity, cargoType, cargoWeightTons },
  });

  dispatchNotification({
    targetRole: "OPERATIONS_MANAGER",
    titleAr: "شحنة جديدة بانتظار الاعتماد",
    titleEn: "New Shipment Awaiting Approval",
    messageAr: `تم إنشاء طلب نقل جديد رقم ${tripNumber} من ${originCity} إلى ${destinationCity}`,
    messageEn: `New trip order ${tripNumber} created from ${originCity} to ${destinationCity}`,
    type: "INFO",
    entityType: "trip",
    entityId: tripId,
    tripId,
  });

  return res.status(201).json({
    message: "Trip created successfully",
    trip: newTrip,
  });
});

// POST /api/trips/:id/transition - Authoritative State Machine Transition
router.post("/:id/transition", authenticate, (req: AuthenticatedRequest, res: Response) => {
  const trip = db.trips.get(String(req.params.id));
  if (!trip) {
    return res.status(404).json({ error: "Trip not found" });
  }

  const { targetStatus, notes, latitude, longitude, reason } = req.body;
  if (!targetStatus) {
    return res.status(400).json({ error: "targetStatus is required" });
  }

  const userRole = req.user?.role || "GUEST";
  const validation = validateTransition(
    trip.status as TripLifecycleStatus,
    targetStatus as TripLifecycleStatus,
    userRole,
    trip,
    reason || notes
  );

  if (!validation.isValid) {
    return res.status(422).json({
      error: validation.error,
      code: "INVALID_TRANSITION",
      currentStatus: trip.status,
      targetStatus,
    });
  }

  const oldStatus = trip.status;
  trip.status = targetStatus;
  trip.updatedAt = new Date().toISOString();

  // If vehicle reached loading or delivery, update coordinates
  if (latitude && longitude) {
    trip.currentLat = latitude;
    trip.currentLng = longitude;
  }

  // Create authoritative event record
  const event: TripEventEntity = {
    id: `ev-${Date.now()}`,
    tripId: trip.id,
    eventType: "STATUS_TRANSITION",
    fromStatus: oldStatus,
    toStatus: targetStatus,
    actorId: req.user?.userId,
    actorName: req.user?.fullName,
    actorRole: req.user?.role,
    notes: notes || reason || `Transitioned from ${oldStatus} to ${targetStatus}`,
    latitude: latitude || trip.currentLat,
    longitude: longitude || trip.currentLng,
    timestamp: new Date().toISOString(),
  };
  db.tripEvents.push(event);

  logAuditEvent({
    actorId: req.user?.userId,
    actorName: req.user?.fullName,
    actorRole: req.user?.role,
    action: "TRIP_STATUS_TRANSITION",
    entity: "trips",
    entityId: trip.id,
    tripId: trip.id,
    oldValues: { status: oldStatus },
    newValues: { status: targetStatus, notes },
    reason,
  });

  dispatchNotification({
    targetRole: "ALL",
    titleAr: `تحديث مسار الرحلة ${trip.tripNumber}`,
    titleEn: `Trip Status Update: ${trip.tripNumber}`,
    messageAr: `تم تحديث حالة الرحلة إلى: ${STATUS_LABELS[targetStatus as TripLifecycleStatus]?.ar || targetStatus}`,
    messageEn: `Trip transitioned to: ${STATUS_LABELS[targetStatus as TripLifecycleStatus]?.en || targetStatus}`,
    type: "SUCCESS",
    entityType: "trip",
    entityId: trip.id,
    tripId: trip.id,
  });

  return res.json({
    message: "Transition successful",
    trip,
    event,
  });
});

// POST /api/trips/:id/cancel
router.post("/:id/cancel", authenticate, (req: AuthenticatedRequest, res: Response) => {
  const tripId = String(req.params.id);
  const trip = db.trips.get(tripId);
  if (!trip) {
    return res.status(404).json({ error: "Trip not found" });
  }

  const { reason } = req.body;
  if (!reason || reason.trim().length < 5) {
    return res.status(400).json({ error: "Cancellation requires a detailed reason (minimum 5 characters)" });
  }

  const userRole = req.user?.role || "";
  const validation = validateTransition(trip.status as TripLifecycleStatus, "CANCELLED", userRole, trip, reason);
  if (!validation.isValid) {
    return res.status(422).json({ error: validation.error });
  }

  const oldStatus = trip.status;
  trip.status = "CANCELLED";
  trip.cancellationReason = reason;
  trip.updatedAt = new Date().toISOString();

  // Free assigned vehicle if not already running
  const vehicle = db.vehicles.get(trip.vehicleId);
  if (vehicle && vehicle.status === "in_trip") {
    vehicle.status = "idle";
  }

  const cancelEvent: TripEventEntity = {
    id: `ev-${Date.now()}`,
    tripId: trip.id,
    eventType: "TRIP_CANCELLED",
    fromStatus: oldStatus,
    toStatus: "CANCELLED",
    actorId: req.user?.userId,
    actorName: req.user?.fullName,
    actorRole: req.user?.role,
    notes: `تم إلغاء الرحلة. سبب الإلغاء: ${reason}`,
    timestamp: new Date().toISOString(),
  };
  db.tripEvents.push(cancelEvent);

  logAuditEvent({
    actorId: req.user?.userId,
    actorName: req.user?.fullName,
    actorRole: req.user?.role,
    action: "TRIP_CANCELLED",
    entity: "trips",
    entityId: trip.id,
    tripId: trip.id,
    oldValues: { status: oldStatus },
    newValues: { status: "CANCELLED", reason },
    reason,
  });

  return res.json({
    message: "Trip cancelled successfully",
    trip,
  });
});

// POST /api/trips/:id/reopen
router.post("/:id/reopen", authenticate, (req: AuthenticatedRequest, res: Response) => {
  const tripId = String(req.params.id);
  const trip = db.trips.get(tripId);
  if (!trip) {
    return res.status(404).json({ error: "Trip not found" });
  }

  if (trip.status !== "CANCELLED") {
    return res.status(400).json({ error: "Only cancelled trips can be reopened." });
  }

  const { reason } = req.body;
  if (!reason || reason.trim().length < 5) {
    return res.status(400).json({ error: "Reopening requires a clear operational justification" });
  }

  const allowedRoles = ["SUPER_ADMIN", "GENERAL_MANAGER"];
  if (!allowedRoles.includes(req.user?.role || "")) {
    return res.status(403).json({ error: "Access denied. Only Super Admin or General Manager can reopen cancelled trips." });
  }

  trip.status = "REOPENED";
  trip.reopeningReason = reason;
  trip.updatedAt = new Date().toISOString();

  const reopenEvent: TripEventEntity = {
    id: `ev-${Date.now()}`,
    tripId: trip.id,
    eventType: "TRIP_REOPENED",
    fromStatus: "CANCELLED",
    toStatus: "REOPENED",
    actorId: req.user?.userId,
    actorName: req.user?.fullName,
    actorRole: req.user?.role,
    notes: `تمت إعادة فتح الرحلة من قبل الإدارة العليا. المبرر: ${reason}`,
    timestamp: new Date().toISOString(),
  };
  db.tripEvents.push(reopenEvent);

  logAuditEvent({
    actorId: req.user?.userId,
    actorName: req.user?.fullName,
    actorRole: req.user?.role,
    action: "TRIP_REOPENED",
    entity: "trips",
    entityId: trip.id,
    tripId: trip.id,
    oldValues: { status: "CANCELLED" },
    newValues: { status: "REOPENED", reason },
    reason,
  });

  return res.json({
    message: "Trip reopened successfully for review",
    trip,
  });
});

// GET /api/trips/:id/events
router.get("/:id/events", (req: AuthenticatedRequest, res: Response) => {
  const tripId = String(req.params.id);
  const events = db.tripEvents.filter((e) => e.tripId === tripId);
  return res.json({ events });
});

export default router;
